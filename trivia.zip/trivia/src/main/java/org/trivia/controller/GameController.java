package org.trivia.controller;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import org.trivia.model.Entry;
import org.trivia.trivia.App;

import java.util.ArrayList;
import java.util.List;

public class GameController {
    private static String username;
    private static List<String> selectedCategory;
    private int currentEntryId = 0;
    private  List<Entry> entries;

    @FXML
    public Text questionText;
    @FXML
    private StackPane barPane;
    @FXML
    private Rectangle backRec;
    @FXML
    private Rectangle topRec;


    @FXML
    public static void newGame(String name, List<String> categories) {
        username = name;
        selectedCategory = categories;
    }

    @FXML
    public void initialize() {
        entries = App.getDbHandler().getEntryByCategories(selectedCategory);
        if  (entries.isEmpty()) {
            questionText.setText("There are no questions to display.");
        }
        displayQuestion(currentEntryId);
    }

    private void displayQuestion(int id) {
        if  (id < entries.size()) {
            questionText.setText(entries.get(id).getQuestion());
            ++currentEntryId;
        }
    }



    @FXML
    public void submitAction() {
        displayQuestion(currentEntryId);
    }
}
