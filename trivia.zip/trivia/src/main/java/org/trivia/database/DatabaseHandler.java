package org.trivia.database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import org.trivia.model.Entry;

public class DatabaseHandler {
    private static final String url = "jdbc:postgresql://localhost:5432/trivia";
    private static final String username = "postgres";
    private static final String password = "javafx";
//    private static Connection connection;
//    private static Statement statement;


    public DatabaseHandler(){}

    public int getEntryCount(){
        int count = 0;
        String query = "SELECT count(1) FROM entries";
        try (Connection connection = DriverManager.getConnection(url, username, password);){
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery(query);
            resultSet.next();
            count = resultSet.getInt(1);
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }

        return count;
    }

    public long insertEntry(Entry entry){
        long id = -1;
        try (
                Connection conn = DriverManager.getConnection(url, username, password);
        ){
            String query = "INSERT INTO entries(question, answer, option2, option3, option4, hint, category, level) VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING id";
            Statement stmt = conn.createStatement();
            try (PreparedStatement pstmt = conn.prepareStatement(query,  Statement.RETURN_GENERATED_KEYS)){
                pstmt.setString(1, entry.getQuestion());
                pstmt.setString(2, entry.getAnswer());
                pstmt.setString(3, entry.getOption2());
                pstmt.setString(4, entry.getOption3());
                pstmt.setString(5, entry.getOption4());
                pstmt.setString(6, entry.getHint());
                pstmt.setString(7, entry.getCategory());
                pstmt.setString(8, entry.getLevel());
                pstmt.execute();

                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        id = rs.getLong(1); // Get the first column of the result set
                        System.out.println("New ID: " + id);
                    }
                }
            }
        }catch  (SQLException e) {
            System.out.println(e.getMessage());
        }
        return id;
    }

    public void deleteEntry(long id){
        String query = String.format("DELETE FROM entries WHERE id = %d", id);
        try (
                Connection conn = DriverManager.getConnection(url, username, password);
        ){
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(query);
        }catch(SQLException e){System.out.println(e.getMessage());}
    }

    public List<Entry> getEntries(){
        List<Entry> entries = new ArrayList<>();
        String  query = "SELECT * FROM entries";
        try (Connection conn = DriverManager.getConnection(url, username, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()) {
                entries.add(new Entry(rs.getInt("id"), rs.getString("question"),
                        rs.getString("answer"), rs.getString("option2"), rs.getString("option3"),
                        rs.getString("option4"), rs.getString("hint"), rs.getString("category"),
                        rs.getString("level")));
            }
        }catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return entries;
    }

    public void updateEntry(Entry entry){
        try (
                Connection conn = DriverManager.getConnection(url, username, password);
        ){
            String query = "update entries set question = ?, answer = ?, option2 = ?, option3 = ?, " +
                    "option4 = ?, hint = ?, category = ?, level = ? where id = ?";
            Statement stmt = conn.createStatement();
            try (PreparedStatement pstmt = conn.prepareStatement(query,  Statement.RETURN_GENERATED_KEYS)){
                pstmt.setString(1, entry.getQuestion());
                pstmt.setString(2, entry.getAnswer());
                pstmt.setString(3, entry.getOption2());
                pstmt.setString(4, entry.getOption3());
                pstmt.setString(5, entry.getOption4());
                pstmt.setString(6, entry.getHint());
                pstmt.setString(7, entry.getCategory());
                pstmt.setString(8, entry.getLevel());
                pstmt.setLong(9, entry.getId());
                pstmt.execute();
            }
        }catch  (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public List<String> getCategories(){
        List<String> categories = new ArrayList<>();
        String  query = "SELECT distinct category FROM entries";
        try (Connection conn = DriverManager.getConnection(url, username, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()) {
                categories.add(rs.getString("category"));
            }
        }catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return categories;
    }

    public List<Entry> getEntryByCategories(List<String> categories){
        List<Entry> entries = new ArrayList<>();
        String  query = "SELECT * FROM entries";

        if  (!categories.isEmpty()){
            query = "SELECT * FROM entries WHERE category IN ('" + String.join("','", categories) + "') limit 10";
        }
        System.out.println(query);

        try (Connection conn = DriverManager.getConnection(url, username, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()) {
                entries.add(new Entry(rs.getInt("id"), rs.getString("question"),
                        rs.getString("answer"), rs.getString("option2"), rs.getString("option3"),
                        rs.getString("option4"), rs.getString("hint"), rs.getString("category"),
                        rs.getString("level")));
            }
        }catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return entries;
    }




}
