package org.trivia.controller;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import org.trivia.database.DatabaseHandler;
import org.trivia.model.Entry;

import org.trivia.trivia.App;

import java.io.IOException;
import java.util.Collections;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class P1_Gameplay_Controller{

    private final DatabaseHandler dataH = new DatabaseHandler();

    protected ArrayList<Entry> runQuest = new ArrayList<>();
    protected ArrayList<Button> AllAnswers = new ArrayList<>();
    protected ArrayList<String> options = new ArrayList<>();

    private static String catorgory;

    private static boolean runStarted = true;


    @FXML protected VBox VBox_Center;

    //change to progress bar
    @FXML private Label timerLabel;
    private final Timeline countdown = new Timeline();
    private final AtomicInteger seconds = new AtomicInteger(50);


    protected int gameRounds = 0;

    @FXML protected Label question_box;

    @FXML protected Label hintLabel;
    @FXML protected Button submitButton;


    @FXML protected Button button_one;
    @FXML protected Button button_two;
    @FXML protected Button button_three;
    @FXML protected Button button_four;

    //@FXML protected Button continueButton;

    @FXML protected Label RightWrong;
    @FXML private ProgressBar progressBar;
    private double progressBarNumber = 0.35;

    protected String answer;
    protected String correctAnswer;
    protected int score = 0;


    public void push(Entry entry)
    {
        runQuest.add(entry);
    }
    public void pop() { runQuest.removeLast(); }
    public Entry peek()
    {
        return runQuest.getLast();
    }


    public static void setCat(String cat){
        catorgory = cat;
    }

    @FXML
    public void initialize()
    {
        if(runStarted)
        {
            runQuest = (ArrayList<Entry>) dataH.getEntryByCategories(List.of(catorgory));
            System.out.println("Run Question have been started");
            runStarted = false;
        }



        System.out.println(runQuest.size() + "\n");
        Collections.shuffle(runQuest);

        if(runQuest.isEmpty()){

        }

        RightWrong.setText(" "+ String.valueOf(score));

        play();
        System.out.println(gameRounds + "\n");

        System.out.println(peek().getQuestion()+ "\n");

        progressBar.setProgress(progressBarNumber);
        gameRounds++;

    }





    public void play()
    {
        //this will start the timer and add new question
        // and increase the rounds and progress bar

        disableAnswerButtons(false);

        seconds.set(50);

        Entry current_entry = peek();

        question_box.setText(current_entry.getQuestion());

        correctAnswer = current_entry.getAnswer();

        hintLabel.setVisible(false);

        options.clear();
        AllAnswers.clear();


        options.add(current_entry.getAnswer());
        options.add(current_entry.getOption2());
        options.add(current_entry.getOption3());
        options.add(current_entry.getOption4());

        Collections.shuffle(options);

        AllAnswers.add(button_one);
        AllAnswers.add(button_two);
        AllAnswers.add(button_three);
        AllAnswers.add(button_four);


        for(int i =0; i < AllAnswers.size(); i++)
        {
            AllAnswers.get(i).setText(options.get(i));
        }


        button_one.setOnAction(e -> {
            answer = AllAnswers.getFirst().getText();
            System.out.println("Answer has been picked: "  + answer);

            AnswerPicked(AllAnswers, answer);

        });


        button_two.setOnAction(e -> {
            answer = AllAnswers.get(1).getText();
            System.out.println("Answer has been picked: "  + answer);

            AnswerPicked(AllAnswers, answer);
        });


        button_three.setOnAction(e -> {
            answer = AllAnswers.get(2).getText();
            System.out.println("Answer has been picked: "  + answer);

            AnswerPicked(AllAnswers, answer);

        });

        button_four.setOnAction(e -> {
            answer = AllAnswers.get(3).getText();
            System.out.println("Answer has been picked: "  + answer);

            AnswerPicked(AllAnswers, answer);
        });

        Time();


    }



    //for testing and debuting
    int somthing = 0;

    public void Time()
    {

        timerLabel.setText(seconds.toString());

        countdown.stop();

        countdown.getKeyFrames().add(new KeyFrame(Duration.seconds(1), e -> {

            seconds.decrementAndGet();
            timerLabel.setText(seconds.toString());

            if(seconds.get() <= 0)
            {
                timerLabel.setText("Times UP!");
                countdown.stop();
            }

            System.out.println("Timer is going by 1 second." + somthing++);


        }));

        countdown.setCycleCount(Timeline.INDEFINITE);
        countdown.play();


    }



    public void AnswerPicked(ArrayList<Button>AllAnswers, String answer)
    {

        for(Button op : AllAnswers)
        {
            if((op.getText()).equals(answer))
            {
                op.setStyle("-fx-background-color: #116f59;" + "-fx-background-radius: 20;" +
                        "-fx-padding: 10");
            }
            else {
                op.setStyle("-fx-background-color: #f4b400;" + "-fx-background-radius: 20;"
                        + "-fx-padding: 10");
            }

        }


    }



    @FXML public void showHint(){

        hintLabel.setText(peek().getHint());
        hintLabel.setVisible(true);

    }


    @FXML public void submitedAswer()
    {


        Label EndRound = new Label();

        for(Button op : AllAnswers)
        {
            if((op.getText()).equals(correctAnswer))
            {
                op.setStyle("-fx-background-color: #116f59;" + "-fx-background-radius: 20;" +
                        "-fx-padding: 10");
            }
            else {
                op.setStyle("-fx-background-color: #c1121f;" + "-fx-background-radius: 20;"
                        + "-fx-padding: 10");
            }

        }

        if(correctAnswer.equals(answer))
        {
            score += 10;

            EndRound.setText("You Got it!!!");
            EndRound.setStyle("-fx-text-fill: #116f59;" +  "-fx-Font-Size: 25px;" + "-fx-font-family: Impact");

            VBox_Center.getChildren().add(EndRound) ;
        }
        else
        {
            score -= 10;
            EndRound.setText("Sorry, your answer is wrong");
            EndRound.setStyle("-fx-text-fill: #c1121f;" +  "-fx-Font-Size: 25px;" + "-fx-font-family: Impact");

            VBox_Center.getChildren().add(EndRound) ;
        }


        //Removes the current question from the stack
        countdown.stop();
        pop();
        disableAnswerButtons(true);


        Button continueButton = new Button("CONTINUE");
        continueButton.setStyle("-fx-background-color: #37344e;" + "-fx-text-fill: #f4b400 ; "
                + "-fx-background-radius: 20;" + "-fx-padding: 10");


        continueButton.setOnAction(e -> {
            continueButtonClicked();
            seconds.set(50);
            VBox_Center.getChildren().removeAll(EndRound, continueButton);
        });


        VBox_Center.getChildren().add(continueButton);

    }


    private void disableAnswerButtons(boolean state) {
        button_one.setDisable(state);
        button_two.setDisable(state);
        button_three.setDisable(state);
        button_four.setDisable(state);
    }



    public void continueButtonClicked()
    {
        initialize();

        for(Button op : AllAnswers)
        {
            op.setStyle("-fx-background-color: #f4b400;" + "-fx-background-radius: 20;" + "-fx-padding: 10");
        }

        hintLabel.setVisible(false);

        //fix this get it to update when the round ends
        progressBarNumber += 0.15;
        play();

    }





    @FXML public void goHome() throws IOException {
        cleanGame();
        App.setRoot("Smarty_Party_HomeScreen");
    }


    public void EndofGame_P1()
    {
        cleanGame();
        //App.setRoot("Leaderboard")

    }

    public void cleanGame()
    {
        runStarted = true;
        runQuest.clear();
        AllAnswers.clear();
        options.clear();
        score = 0;
        progressBarNumber = 0;
        countdown.stop();
    }



}
